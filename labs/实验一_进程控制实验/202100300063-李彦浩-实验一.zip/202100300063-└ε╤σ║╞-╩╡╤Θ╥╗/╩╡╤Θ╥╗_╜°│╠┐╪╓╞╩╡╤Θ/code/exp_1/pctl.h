#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>//wait()
#include <unistd.h> //fork() exec()
#include <wait.h>//wait()
//进程自定义的键盘中断信号处理函数
typedef void (*sighandler_t) (int);
void sigcat() { printf("%d Process continue\n", getpid()); }
