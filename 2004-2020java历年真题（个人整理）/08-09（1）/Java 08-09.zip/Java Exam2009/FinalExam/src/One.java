
public class One {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		int x = 1;
		int y = 2;
		System.out.println("1" + x +y); 

	}

}
